#include<stdio.h>
#include<stdlib.h>
int fibonacci(int);


int main()
{
	int a;
	printf("�п�J�X��FIBONACCI��:");
	scanf_s("%d", &a);
	printf("�ƭȬ�: %d\n", fibonacci(a));
	system("pause");
	return 0;
}
int fibonacci(int n)
{
	int x = 0, y = 1, z, i;
	if (n == 0)
	{
		return x;
	}
	for (i = 2; i <= n; i++)
	{
		z = x + y;
		x = y;
		y = z;
	}
	return y;
}