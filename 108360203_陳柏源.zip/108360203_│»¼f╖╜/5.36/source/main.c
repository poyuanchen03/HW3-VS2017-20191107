#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int movedisk(int n, int speg, int epeg, int hpeg);
	int n, speg, epeg, hpeg;

	printf("�п�J�L�l�ƶq: ");
	scanf_s("%d", &n);
	printf("�п�J�}�l���W�l�s�� (1, 2, 3): ");
	scanf_s("%d", &speg);
	printf("�п�J�̫᪺�W�l�s�� (1, 2, 3): ");
	scanf_s("%d", &epeg);

	if ((speg == 1 && epeg == 2) || (speg == 2 && epeg == 1))
	{
		hpeg = 3;
	}
	if ((speg == 1 && epeg == 3) || (speg == 3 && epeg == 1))
	{
		hpeg = 2;
	}
	if ((speg == 2 && epeg == 3) || (speg == 3 && epeg == 2))
	{
		hpeg = 1;
	}
	if (speg == epeg)
	{
		return 0;
	}
	movedisk(n, speg, epeg, hpeg);

	system("pause");
	return 0;
}
int movedisk(int n, int speg, int epeg, int hpeg)
{
	if (n == 1)
	{
		printf("���ʽL�l %d -> %d\n", speg, epeg);
	}
	else
	{
		movedisk((n - 1), speg, hpeg, epeg);
		printf("���ʽL�l %d -> %d\n", speg, epeg);
		movedisk((n - 1), hpeg, epeg, speg);
	}
}
