#include<stdio.h>
#include<stdlib.h>
int process(int x, int y);
int num(int x, int y);

int main()
{
	int a, b;
	printf("�п�J��Ӽƭ�:");
	scanf_s("%d %d", &a, &b);
	printf("%d �� %d ��ƪ��̤p�����Ƭ�: %d\n", a, b, num(a,b));
	system("pause");
	return 0;
}
int process(int x, int y)
{
	if (x == 0)
	{
		return y;
	}
	return process(y % x, x);
}
int num(int x, int y)
{
	return (x * y) / process(x, y);
}